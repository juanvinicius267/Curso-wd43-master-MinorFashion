# Projeto wd47

- Neste repositório iremos organizar todo o código que servira de base para os exercícios da apostila;
- Cada exercício deverá ser mantido em uma branch. 
- O HTML e CSS necessários deverão ser incluidos na branch master.
- Para conseguir determinar a ordem que cada exercício aparece na apostila, temos um [Project](https://github.com/caelum/projeto-wd47/projects/1) aqui mesmo no Github. Quando um exercício novo for criado, o mesmo deve ser adicionado neste projeto, na ordem em que ele aparece e de preferência com uma descrição para servir de base para quem for escrever o conteúdo.
