console.log("Variáveis em JavaScript:")

/*
    Regras para definição de variáveis
    Não pode ser palavra da própria linguagem
    Deve ter claro o seu significado
    Não pode começar por número
    Não pode conter espaços no nome
    Há diferenciação entre maiúsculas e minúsculas
*/

let nomeDoAluno = "Carlos"

let codigoDoProduto = 12345
console.log("Código do Produto: ", codigoDoProduto)

/*
    Tipos de variáveis
    const - constantes, não podem variar
    let - podem ter seu valor alterado
    var - igual ao let, porém pode ser redefinido (em desuso)
*/
const PI = 3.14
const CPF = "071.092.935-72"

let carlos 
// é diferente de 
let Carlos

carlos = "nome com minúsculo"
Carlos = "Nome com maiúsculo"
console.log(carlos, " é diferente de ", Carlos)





